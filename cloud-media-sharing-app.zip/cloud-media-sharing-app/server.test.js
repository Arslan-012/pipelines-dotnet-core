const request = require('supertest');
const app = require('./server');

describe('Media Sharing API', () => {
    let testToken;
    let testMediaId;

    test('User Registration', async () => {
        const res = await request(app)
            .post('/api/register')
            .send({
                username: 'testuser',
                password: 'testpass',
                email: 'test@example.com',
                role: 'creator'
            });
        expect(res.statusCode).toBe(201);
        expect(res.body.token).toBeDefined();
        testToken = res.body.token;
    });

    test('Media Upload (Creator)', async () => {
        const res = await request(app)
            .post('/api/media/upload')
            .set('Authorization', `Bearer ${testToken}`)
            .field('title', 'Test Media')
            .field('caption', 'Test caption')
            .attach('file', Buffer.from('test image'), 'test.jpg');
        
        expect(res.statusCode).toBe(201);
        testMediaId = res.body.media.id;
    });

    test('Get Media Feed', async () => {
        const res = await request(app).get('/api/media/feed');
        expect(res.statusCode).toBe(200);
        expect(Array.isArray(res.body)).toBe(true);
    });
});