import React from 'react';
import SearchIcon from '@mui/icons-material/Search';

export const SearchBtnIcon = () => <SearchIcon />
