import React from 'react';
import { AddCircle, AddCircleOutline } from '@mui/icons-material';

export const CreateUnselected = () => <AddCircleOutline />
export const CreateSelected = () => <AddCircle />