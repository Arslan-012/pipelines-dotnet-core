import React from 'react';
import { Settings } from '@mui/icons-material';

export const SettingsIcon = () => <Settings className='cursor-pointer'/>
