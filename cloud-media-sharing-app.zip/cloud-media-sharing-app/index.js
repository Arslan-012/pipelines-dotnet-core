const { BlobServiceClient } = require('@azure/storage-blob');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

module.exports = async function (context, req) {
    try {
        const { fileName, userId } = req.body;
        
        if (!fileName) {
            context.res = {
                status: 400,
                body: "File name is required"
            };
            return;
        }
        
        // Download video from Blob Storage
        const blobServiceClient = BlobServiceClient.fromConnectionString(process.env.AZURE_STORAGE_CONNECTION_STRING);
        const containerClient = blobServiceClient.getContainerClient('media-container');
        const blobClient = containerClient.getBlobClient(fileName);
        
        // Create temp directory
        const tempDir = `/tmp/${uuidv4()}`;
        fs.mkdirSync(tempDir, { recursive: true });
        
        const inputPath = path.join(tempDir, 'input.mp4');
        const outputPath = path.join(tempDir, 'output_360p.mp4');
        const thumbnailPath = path.join(tempDir, 'thumbnail.jpg');
        
        // Download blob
        const downloadResponse = await blobClient.download();
        const writeStream = fs.createWriteStream(inputPath);
        downloadResponse.readableStreamBody.pipe(writeStream);
        
        await new Promise((resolve, reject) => {
            writeStream.on('finish', resolve);
            writeStream.on('error', reject);
        });
        
        // Convert video to 360p
        await new Promise((resolve, reject) => {
            exec(`ffmpeg -i ${inputPath} -vf scale=640:360 ${outputPath}`, (error, stdout, stderr) => {
                if (error) reject(error);
                else resolve();
            });
        });
        
        // Generate thumbnail
        await new Promise((resolve, reject) => {
            exec(`ffmpeg -i ${inputPath} -ss 00:00:01 -vframes 1 ${thumbnailPath}`, (error) => {
                if (error) reject(error);
                else resolve();
            });
        });
        
        // Upload processed files
        const processedBlobClient = containerClient.getBlockBlobClient(`processed/${fileName}`);
        const thumbnailBlobClient = containerClient.getBlockBlobClient(`thumbnails/${fileName.replace('.mp4', '.jpg')}`);
        
        await processedBlobClient.uploadFile(outputPath);
        await thumbnailBlobClient.uploadFile(thumbnailPath);
        
        // Cleanup
        fs.rmSync(tempDir, { recursive: true, force: true });
        
        context.res = {
            status: 200,
            body: {
                message: "Video processed successfully",
                processedUrl: processedBlobClient.url,
                thumbnailUrl: thumbnailBlobClient.url
            }
        };
        
    } catch (error) {
        context.log.error('Processing error:', error);
        context.res = {
            status: 500,
            body: "Video processing failed"
        };
    }
};