const express = require('express');
const multer = require('multer');
const { BlobServiceClient } = require('@azure/storage-blob');
const { CosmosClient } = require('@cosmos-client');
const jwt = require('jsonwebtoken');
const app = express();
require('dotenv').config();

// Azure Configuration
const AZURE_STORAGE_CONNECTION_STRING = process.env.AZURE_STORAGE_CONNECTION_STRING;
const CONTAINER_NAME = 'media-container';
const COSMOS_ENDPOINT = process.env.COSMOS_ENDPOINT;
const COSMOS_KEY = process.env.COSMOS_KEY;
const JWT_SECRET = process.env.JWT_SECRET;

// Initialize Azure Clients
const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE_STORAGE_CONNECTION_STRING);
const containerClient = blobServiceClient.getContainerClient(CONTAINER_NAME);
const cosmosClient = new CosmosClient({ endpoint: COSMOS_ENDPOINT, key: COSMOS_KEY });
const database = cosmosClient.database('mediaDB');
const usersContainer = database.container('users');
const mediaContainer = database.container('media');

// Middleware
app.use(express.json());
const upload = multer({ storage: multer.memoryStorage() });

// Authentication Middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Check Creator Role Middleware
const creatorOnly = (req, res, next) => {
    if (req.user.role !== 'creator') return res.status(403).json({ error: 'Only creators can upload' });
    next();
};

// 1. User Registration
app.post('/api/register', async (req, res) => {
    const { username, password, email, role } = req.body;
    
    // Hash password (use bcrypt in production)
    const hashedPassword = password; // Simplified for example
    
    const user = {
        id: Date.now().toString(),
        username,
        password: hashedPassword,
        email,
        role: role || 'consumer',
        createdAt: new Date().toISOString()
    };
    
    try {
        await usersContainer.items.create(user);
        const token = jwt.sign({ id: user.id, username, role: user.role }, JWT_SECRET);
        res.status(201).json({ token, user: { id: user.id, username, role: user.role } });
    } catch (error) {
        res.status(500).json({ error: 'Registration failed' });
    }
});

// 2. Login
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    
    try {
        const querySpec = {
            query: "SELECT * FROM c WHERE c.username = @username",
            parameters: [{ name: "@username", value: username }]
        };
        
        const { resources: users } = await usersContainer.items.query(querySpec).fetchAll();
        
        if (users.length === 0 || users[0].password !== password) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        const user = users[0];
        const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET);
        res.json({ token, user: { id: user.id, username: user.username, role: user.role } });
    } catch (error) {
        res.status(500).json({ error: 'Login failed' });
    }
});

// 3. Upload Media (Photo/Video) - Creator Only
app.post('/api/media/upload', authenticateToken, creatorOnly, upload.single('file'), async (req, res) => {
    try {
        const { title, caption, location, tags } = req.body;
        const file = req.file;
        const userId = req.user.id;
        
        if (!file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }
        
        // Generate unique filename
        const timestamp = Date.now();
        const fileExtension = file.originalname.split('.').pop();
        const fileName = `${userId}_${timestamp}.${fileExtension}`;
        
        // Upload to Azure Blob Storage
        const blockBlobClient = containerClient.getBlockBlobClient(fileName);
        await blockBlobClient.upload(file.buffer, file.buffer.length);
        
        // Get public URL
        const mediaUrl = blockBlobClient.url;
        
        // Store metadata in Cosmos DB
        const mediaItem = {
            id: Date.now().toString(),
            userId,
            fileName,
            mediaUrl,
            title: title || '',
            caption: caption || '',
            location: location || '',
            tags: tags ? tags.split(',') : [],
            type: file.mimetype.startsWith('video') ? 'video' : 'image',
            uploadDate: new Date().toISOString(),
            likes: 0,
            comments: []
        };
        
        await mediaContainer.items.create(mediaItem);
        
        // If video, trigger media conversion (async)
        if (mediaItem.type === 'video') {
            // Call Azure Function for video processing
            // This would be an HTTP trigger to Azure Functions
            // await axios.post(process.env.MEDIA_CONVERSION_URL, { fileName, userId });
        }
        
        res.status(201).json({
            message: 'Media uploaded successfully',
            media: mediaItem
        });
    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ error: 'Upload failed' });
    }
});

// 4. Get Media Feed (Public)
app.get('/api/media/feed', async (req, res) => {
    try {
        const querySpec = {
            query: "SELECT * FROM c ORDER BY c.uploadDate DESC"
        };
        
        const { resources: mediaItems } = await mediaContainer.items.query(querySpec).fetchAll();
        res.json(mediaItems);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch media' });
    }
});

// 5. Add Comment (Authenticated Users)
app.post('/api/media/:id/comment', authenticateToken, async (req, res) => {
    try {
        const mediaId = req.params.id;
        const { text } = req.body;
        const userId = req.user.id;
        const username = req.user.username;
        
        const comment = {
            id: Date.now().toString(),
            userId,
            username,
            text,
            timestamp: new Date().toISOString()
        };
        
        // Get media item
        const mediaItem = await mediaContainer.item(mediaId, mediaId).read();
        
        if (!mediaItem.resource) {
            return res.status(404).json({ error: 'Media not found' });
        }
        
        // Add comment
        const updatedComments = [...mediaItem.resource.comments, comment];
        
        await mediaContainer.item(mediaId, mediaId).replace({
            ...mediaItem.resource,
            comments: updatedComments
        });
        
        res.json({ message: 'Comment added', comment });
    } catch (error) {
        res.status(500).json({ error: 'Failed to add comment' });
    }
});

// 6. Like Media
app.post('/api/media/:id/like', authenticateToken, async (req, res) => {
    try {
        const mediaId = req.params.id;
        
        const mediaItem = await mediaContainer.item(mediaId, mediaId).read();
        
        if (!mediaItem.resource) {
            return res.status(404).json({ error: 'Media not found' });
        }
        
        const updatedLikes = mediaItem.resource.likes + 1;
        
        await mediaContainer.item(mediaId, mediaId).replace({
            ...mediaItem.resource,
            likes: updatedLikes
        });
        
        res.json({ message: 'Media liked', likes: updatedLikes });
    } catch (error) {
        res.status(500).json({ error: 'Failed to like media' });
    }
});

// 7. Search Media
app.get('/api/media/search', async (req, res) => {
    try {
        const query = req.query.q;
        
        if (!query) {
            return res.status(400).json({ error: 'Search query required' });
        }
        
        const querySpec = {
            query: "SELECT * FROM c WHERE CONTAINS(c.title, @query) OR CONTAINS(c.caption, @query) OR ARRAY_CONTAINS(c.tags, @query)",
            parameters: [{ name: "@query", value: query }]
        };
        
        const { resources: results } = await mediaContainer.items.query(querySpec).fetchAll();
        res.json(results);
    } catch (error) {
        res.status(500).json({ error: 'Search failed' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});